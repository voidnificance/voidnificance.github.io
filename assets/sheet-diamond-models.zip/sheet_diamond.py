"""Rebuild a Sheet-Diamond TPMS coupon using a nodal approximation.

Units are millimeters. Export a closed triangle mesh in binary STL.
Requires NumPy, SciPy and scikit-image.
"""
import argparse
from pathlib import Path
import struct

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from skimage.measure import marching_cubes


def make_coupon(void_fraction, size_mm=20.0, cells=2, samples=60):
    """Return vertices, outward triangles, band threshold, and mesh void fraction."""
    spacing = size_mm / samples
    coordinates = np.linspace(-spacing, size_mm + spacing, samples + 3)
    phase = coordinates * (2 * np.pi * cells / size_mm)
    x, y, z = np.meshgrid(phase, phase, phase, indexing="ij", sparse=True)
    x, y, z = x + 0.17, y + 0.26, z + 0.36
    diamond = np.abs(np.cos(x) * np.cos(y) * np.cos(z) -
                     np.sin(x) * np.sin(y) * np.sin(z))
    threshold = np.quantile(diamond[1:-2, 1:-2, 1:-2], 1 - void_fraction)
    distance = np.minimum(coordinates, size_mm - coordinates)
    clip = np.minimum(np.minimum(distance[:, None, None], distance[None, :, None]),
                      distance[None, None, :])
    # Lift exact zeros slightly to keep clipping caps manifold on the sampled planes.
    field = np.minimum(threshold - diamond, clip / spacing + 0.001)
    vertices, faces, _, _ = marching_cubes(field, 0, spacing=(spacing,) * 3,
                                            allow_degenerate=False)
    vertices = np.clip(vertices - spacing, 0, size_mm).astype(np.float32)
    vertices, indices = np.unique(vertices, axis=0, return_inverse=True)
    faces = indices[faces].astype(np.int32)
    distinct = ((faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2])
                & (faces[:, 2] != faces[:, 0]))
    faces = faces[distinct]
    a, b, c = vertices[faces].transpose(1, 0, 2)
    volume = np.einsum("ij,ij->i", a, np.cross(b, c)).sum(dtype=np.float64) / 6
    if volume < 0:
        faces = faces[:, ::-1].copy()
        volume = -volume
    return vertices, faces, float(threshold), float(1 - volume / size_mm**3)


def check_mesh(vertices, faces):
    edge_pairs = np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]])
    edges, count = np.unique(np.sort(edge_pairs, axis=1), axis=0, return_counts=True)
    adjacency = coo_matrix((np.ones(len(edges)), (edges[:, 0], edges[:, 1])),
                           shape=(len(vertices), len(vertices))).tocsr()
    n_components = connected_components(adjacency, directed=False, return_labels=False)
    a, b, c = vertices[faces].transpose(1, 0, 2)
    if np.any(np.linalg.norm(np.cross(b - a, c - a), axis=1) == 0):
        raise ValueError("Found a zero-area triangle")
    if not np.all(count == 2) or n_components != 1:
        raise ValueError("Expected one closed, connected sheet mesh")


def save_stl(path, vertices, faces):
    triangles = vertices[faces]
    normals = np.cross(triangles[:, 1] - triangles[:, 0],
                       triangles[:, 2] - triangles[:, 0])
    normals /= np.linalg.norm(normals, axis=1)[:, None]
    records = np.zeros(len(faces), dtype=[("normal", "<f4", (3,)),
                                            ("vertices", "<f4", (3, 3)),
                                            ("attribute", "<u2")])
    records["normal"] = normals
    records["vertices"] = triangles
    with path.open("wb") as output:
        output.write(b"Sheet-Diamond portfolio reconstruction (mm)".ljust(80, b" "))
        output.write(struct.pack("<I", len(faces)))
        output.write(records.tobytes())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--void", type=float, choices=(0.55, 0.70, 0.80), default=0.70)
    arguments = parser.parse_args()
    vertices, faces, band, porosity = make_coupon(arguments.void)
    check_mesh(vertices, faces)
    save_stl(arguments.output, vertices, faces)
    print(f"{len(faces):,} faces, band {band:.5f}, mesh porosity {100 * porosity:.2f}%")
