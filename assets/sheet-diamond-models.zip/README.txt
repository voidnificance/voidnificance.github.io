Sheet-Diamond TPMS | Portfolio reconstruction

Reference: Cai et al., Bio-Design and Manufacturing (2019), DOI 10.1007/s42242-019-00054-7.
These are independent demonstration meshes inspired by the published topology. Units are mm.
Envelope 20 mm cube; two field periods along each axis. Each export is a connected closed mesh.
55% target | 55.92% mesh void fraction | 181,504 triangles | threshold 0.37860
70% target | 70.85% mesh void fraction | 185,984 triangles | threshold 0.25265
80% target | 80.01% mesh void fraction | 184,576 triangles | threshold 0.17499

Regenerate: python sheet_diamond.py sheet-diamond-70pct.stl --void 0.70
Requires numpy, scipy, scikit-image. For SolidWorks import the STL in millimeters; the file is faceted.
